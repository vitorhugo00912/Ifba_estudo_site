
import { useState } from 'react'
import { QUESTIONS } from '../data/questions'

function shuffle(arr) {
  return [...arr].sort(() => Math.random() - 0.5)
}

function Quiz({ subject, onGoEstudos }) {
  const base = QUESTIONS[subject] || []
  const [questions, setQuestions] = useState(() => shuffle(base))
  const [index, setIndex] = useState(0)
  const [answers, setAnswers] = useState([])
  const [value, setValue] = useState('')
  const [finished, setFinished] = useState(false)

  function handleNext() {
    const a = value.trim() || '(sem resposta)'
    setAnswers(prev => [...prev, a])
    setValue('')
    if (index + 1 < questions.length) {
      setIndex(index + 1)
    } else {
      setFinished(true)
    }
  }

  function restartDifferent() {
    const newQs = shuffle(QUESTIONS[subject])
    setQuestions(newQs)
    setIndex(0)
    setAnswers([])
    setValue('')
    setFinished(false)
  }

  return (
    <div className="card">
      {!finished ? (
        <>
          <div className="question">
            <strong>Pergunta {index + 1} / {questions.length}</strong>
            <p>{questions[index].q}</p>
          </div>
          <input className="input" value={value} onChange={e=>setValue(e.target.value)} placeholder="Digite sua resposta aqui" />
          <div className="footer">
            <button className="button secondary" onClick={onGoEstudos}>Estudar</button>
            <button className="button" onClick={handleNext}>{index + 1 === questions.length ? 'Finalizar' : 'Próxima'}</button>
          </div>
        </>
      ) : (
        <>
          <h3>Gabarito</h3>
          <div>
            {questions.map((q,i)=>(
              <div key={i} style={{marginBottom:12}}>
                <strong>{i+1}. {q.q}</strong>
                <div><small className="gray">Sua resposta: {answers[i]}</small></div>
                <div>Correto: {q.a}</div>
              </div>
            ))}
          </div>
          <div className="footer" style={{marginTop:12}}>
            <button className="button secondary" onClick={onGoEstudos}>Estudar</button>
            <button className="button" onClick={restartDifferent}>Fazer outro quiz</button>
          </div>
        </>
      )}
    </div>
  )
}

export default function Home() {
  const [tab, setTab] = useState('estudos')

  function goEstudos() {
    setTab('estudos')
    window.scrollTo({top:0, behavior:'smooth'})
  }

  return (
    <div className="container">
      <nav className="nav">
        <button className="button" onClick={()=>setTab('estudos')}>Estudos</button>
        <button className="button" onClick={()=>setTab('portugues')}>Quiz Português</button>
        <button className="button" onClick={()=>setTab('matematica')}>Quiz Matemática</button>
        <button className="button" onClick={()=>setTab('humanas')}>Quiz Ciências Humanas</button>
        <button className="button" onClick={()=>setTab('natureza')}>Quiz Ciências da Natureza</button>
        <button className="button" onClick={()=>setTab('redacao')}>Quiz Redação</button>
      </nav>

      {tab === 'estudos' && (
        <div className="card">
          <h1>Conteúdos de Estudos - IFBA 2026</h1>
          <p>Este espaço traz um resumo detalhado por matéria, como se fosse uma aula pronta para revisão.</p>

          <h2>Português</h2>
          <p><strong>Interpretação de texto:</strong> leia com atenção, identifique ideia central, inferências e intencionalidade do autor. Treine com textos diversos e perguntas objetivas.</p>
          <p><strong>Gramática:</strong> foco em classes gramaticais, sintaxe (sujeito e predicado), crase, concordância nominal e verbal, regência e pontuação.</p>
          <p><strong>Literatura:</strong> movimentos literários básicos, autores brasileiros importantes e características das principais obras.</p>

          <h2>Matemática</h2>
          <p><strong>Álgebra:</strong> equações de 1º e 2º grau, sistemas simples, expressões algébricas.</p>
          <p><strong>Geometria:</strong> áreas, perímetros, semelhança, teorema de Pitágoras.</p>
          <p><strong>Raciocínio e porcentagens:</strong> juros simples, regra de três, média e proporção.</p>

          <h2>Ciências Humanas</h2>
          <p><strong>História:</strong> principais períodos do Brasil (colonial, imperial, república, ditadura), movimentos sociais e datas importantes.</p>
          <p><strong>Geografia:</strong> aspectos físicos do Brasil, regiões, clima, recursos naturais e noções de cartografia.</p>
          <p><strong>Atualidades:</strong> acompanhe notícias e relacione com conceitos históricos e geográficos.</p>

          <h2>Ciências da Natureza</h2>
          <p><strong>Biologia:</strong> célula, órgãos, sistemas do corpo humano, ecologia e evolução.</p>
          <p><strong>Química:</strong> noções de átomos, moléculas, reações químicas, pH e substâncias comuns.</p>
          <p><strong>Física:</strong> forças, energia, velocidade, leis básicas e eletricidade simples.</p>

          <h2>Redação</h2>
          <p>Formato esperado: <em>dissertativo-argumentativo</em>. Estrutura recomendada: introdução (apresenta tema + tese), 2 ou 3 parágrafos de desenvolvimento (argumentos + exemplos) e conclusão (retoma tese e propõe solução ou fechamento).</p>
          <p>Dicas: planeje no rascunho, use linguagem formal, evite gírias, revise gramática e pontuação. Apresente proposta de intervenção quando apropriado.</p>

          <p style={{marginTop:12}}><small className="gray">Dica final: estude com questões, cronometre sua redação e revise os erros mais comuns.</small></p>
        </div>
      )}

      {tab !== 'estudos' && (
        <div style={{marginTop:8}}>
          <Quiz subject={tab} onGoEstudos={goEstudos} />
        </div>
      )}

    </div>
  )
}
