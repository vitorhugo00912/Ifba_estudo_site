
export const QUESTIONS = {
  portugues: [
    { q: "Qual é o sujeito da frase: 'Os alunos estudam bastante'?", a: "Os alunos" },
    { q: "Encontre o verbo: 'A menina correu rápido'.", a: "correu" },
    { q: "Classifique a palavra 'feliz' (classe gramatical).", a: "adjetivo" },
    { q: "O que é um predicado na oração?", a: "o que se declara sobre o sujeito" },
    { q: "Identifique o conectivo: 'Ele estudou, portanto passou'.", a: "portanto" },
    { q: "Assinale a alternativa com crase:", a: "à (a + a)" },
    { q: "O que é coesão textual?", a: "ligação entre as partes do texto" },
    { q: "Defina sinonímia.", a: "palavras com sentido semelhante" },
    { q: "O que é voz passiva?", a: "quando o sujeito recebe a ação" },
    { q: "Qual é o gênero textual mais comum em provas: narração, dissertação ou descrição?", a: "dissertação" }
  ],
  matematica: [
    { q: "Quanto é 7 × 8?", a: "56" },
    { q: "Raiz quadrada de 144?", a: "12" },
    { q: "Qual é a porcentagem de 50 em 200?", a: "25%" },
    { q: "Resolva: 3 + 4 × 2", a: "11" },
    { q: "MDC de 12 e 18", a: "6" },
    { q: "MMC de 4 e 6", a: "12" },
    { q: "Área de um quadrado de lado 5", a: "25" },
    { q: "Perímetro de um retângulo 3×7", a: "20" },
    { q: "Equação: x + 5 = 12, x = ?", a: "7" },
    { q: "Qual a média de 4, 6 e 8?", a: "6" }
  ],
  humanas: [
    { q: "Quem foi o primeiro presidente do Brasil?", a: "Deodoro da Fonseca" },
    { q: "Capital da França?", a: "Paris" },
    { q: "O que foi a Era Vargas?", a: "período de governo de Getúlio Vargas" },
    { q: "Explique brevemente o Iluminismo.", a: "movimento intelectual que valorizou razão e direitos" },
    { q: "O que é cidadania?", a: "conjunto de direitos e deveres do indivíduo" },
    { q: "Qual continente é o Brasil?", a: "América do Sul" },
    { q: "O que estuda a sociologia?", a: "a sociedade e suas relações" },
    { q: "O que faz um historiador?", a: "estuda o passado e interpreta eventos" },
    { q: "Explique imperialismo.", a: "expansão política e econômica de um país sobre outros" },
    { q: "O que é constituição?", a: "conjunto de leis fundamentais do país" }
  ],
  natureza: [
    { q: "Símbolo químico da água?", a: "H2O" },
    { q: "Qual planeta é conhecido como planeta vermelho?", a: "Marte" },
    { q: "Qual órgão realiza a circulação sanguínea?", a: "coração" },
    { q: "O que é fotossíntese?", a: "processo das plantas para produzir alimento usando luz" },
    { q: "Qual é a unidade básica da vida?", a: "célula" },
    { q: "O que é uma reação química?", a: "transformação de substâncias em outras" },
    { q: "Qual gás os seres humanos exalam?", a: "CO2" },
    { q: "O que é massa?", a: "quantidade de matéria" },
    { q: "O que estuda a física?", a: "movimento, energia e forças" },
    { q: "O que estuda a química?", a: "composição e propriedades das substâncias" }
  ],
  redacao: [
    { q: "O que é tese em um texto dissertativo-argumentativo?", a: "ideia central defendida" },
    { q: "Quais são os elementos essenciais de uma introdução?", a: "apresentação do tema e tese" },
    { q: "Como estruturar um parágrafo argumentativo?", a: "tese, argumento, exemplificação, conclusão" },
    { q: "O que é coesão?", a: "ligação entre frases e parágrafos" },
    { q: "O que é coerência?", a: "consistência lógica das ideias" },
    { q: "Como finalizar uma redação?", a: "retomar tese e apresentar proposta/fecho" },
    { q: "Cite uma boa estratégia para argumentar.", a: "usar dados, citações e exemplos" },
    { q: "O que evitar em uma redação formal?", a: "gírias, abreviações e falhas gramaticais" },
    { q: "Qual o papel da conclusão?", a: "encerrar e reafirmar a tese" },
    { q: "Como planejar a redação antes de escrever?", a: "fazer rascunho com pontos principais" }
  ]
};
